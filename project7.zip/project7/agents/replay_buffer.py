import numpy as np
import random
from collections import deque

class ReplayBuffer:
    def __init__(self, capacity=100000):
        self.buffer = deque(maxlen=capacity)

    def push(self, obs_all, acts_all, rews_all, next_obs_all, dones):
        self.buffer.append((obs_all, acts_all, rews_all, next_obs_all, dones))

    def sample(self, batch_size=256):
        batch = random.sample(self.buffer, batch_size)
        obs, acts, rews, next_obs, dones = zip(*batch)
        return (
            np.array(obs),
            np.array(acts),
            np.array(rews),
            np.array(next_obs),
            np.array(dones)
        )

    def __len__(self):
        return len(self.buffer)

import torch
import torch.nn as nn
import numpy as np
from agents.actor import Actor
from agents.critic import Critic


class MADDPGAgent:
    def __init__(self, obs_dim, action_dim, total_obs_dim, total_action_dim,
                 hidden=256, lr_actor=1e-4, lr_critic=3e-4):
        self.actor        = Actor(obs_dim, action_dim, hidden)
        self.actor_target = Actor(obs_dim, action_dim, hidden)
        self.actor_target.load_state_dict(self.actor.state_dict())

        self.critic        = Critic(total_obs_dim, total_action_dim, hidden)
        self.critic_target = Critic(total_obs_dim, total_action_dim, hidden)
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.actor_opt  = torch.optim.Adam(self.actor.parameters(),  lr=lr_actor)
        self.critic_opt = torch.optim.Adam(self.critic.parameters(), lr=lr_critic)

    def soft_update(self, tau=0.01):
        for t, s in zip(self.actor_target.parameters(), self.actor.parameters()):
            t.data.copy_(tau * s.data + (1 - tau) * t.data)
        for t, s in zip(self.critic_target.parameters(), self.critic.parameters()):
            t.data.copy_(tau * s.data + (1 - tau) * t.data)


class MADDPG:
    def __init__(self, n_agents, obs_dim, action_dim, hidden=256,
                 lr_actor=1e-4, lr_critic=3e-4, gamma=0.95, tau=0.01):
        self.n_agents   = n_agents
        self.action_dim = action_dim
        self.gamma      = gamma
        self.tau        = tau
        total_obs_dim    = obs_dim * n_agents
        total_action_dim = action_dim * n_agents
        self.agents = [
            MADDPGAgent(obs_dim, action_dim, total_obs_dim, total_action_dim,
                        hidden, lr_actor, lr_critic)
            for _ in range(n_agents)
        ]

    def select_actions(self, obs_all, noise=0.2):
        actions = []
        for i, agent in enumerate(self.agents):
            obs_t  = torch.FloatTensor(obs_all[i]).unsqueeze(0)
            action = agent.actor(obs_t).detach().numpy()[0]
            action += np.random.randn(*action.shape) * noise
            actions.append(np.clip(action, -1, 1))
        return actions

    def update(self, buffer, batch_size=256):
        if len(buffer) < batch_size:
            return
        obs, acts, rews, next_obs, dones = buffer.sample(batch_size)

        obs_t      = torch.FloatTensor(obs)
        acts_t     = torch.FloatTensor(acts)
        rews_t     = torch.FloatTensor(rews)
        next_obs_t = torch.FloatTensor(next_obs)
        dones_t    = torch.FloatTensor(dones)

        all_obs      = obs_t.view(batch_size, -1)
        all_acts     = acts_t.view(batch_size, -1)
        all_next_obs = next_obs_t.view(batch_size, -1)

        for i, agent in enumerate(self.agents):
            next_acts = torch.cat([
                self.agents[j].actor_target(next_obs_t[:, j, :])
                for j in range(self.n_agents)
            ], dim=-1)

            with torch.no_grad():
                q_target = rews_t[:, i].unsqueeze(1) + self.gamma * (
                    1 - dones_t[:, i].unsqueeze(1)
                ) * agent.critic_target(all_next_obs, next_acts)

            q_current = agent.critic(all_obs, all_acts)
            critic_loss = nn.MSELoss()(q_current, q_target)
            agent.critic_opt.zero_grad()
            critic_loss.backward()
            agent.critic_opt.step()

            curr_acts = torch.cat([
                self.agents[j].actor(obs_t[:, j, :]) if j == i
                else self.agents[j].actor(obs_t[:, j, :]).detach()
                for j in range(self.n_agents)
            ], dim=-1)

            actor_loss = -agent.critic(all_obs, curr_acts).mean()
            agent.actor_opt.zero_grad()
            actor_loss.backward()
            agent.actor_opt.step()
            agent.soft_update(self.tau)

    def save(self, path):
        torch.save({
            f'actor_{i}': self.agents[i].actor.state_dict()
            for i in range(self.n_agents)
        }, path)

    def load(self, path):
        ckpt = torch.load(path)
        for i in range(self.n_agents):
            self.agents[i].actor.load_state_dict(ckpt[f'actor_{i}'])

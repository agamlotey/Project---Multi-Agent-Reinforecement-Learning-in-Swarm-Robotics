"""
visualize_3d.py - 3D PyBullet visualization of the trained MARL swarm policy.

Loads checkpoints/best_model.pt and renders agents, goals, and dynamic obstacles
in a proper 3D world with perspective, lighting, and shadows.

The underlying policy and physics are still the 2D point-mass model from
swarm_env.py. PyBullet is used purely as a visualizer here -- it maps the
2D positions into a 3D scene with cylindrical robots on a floor, spherical
obstacles, and translucent goal disks.

Controls (PyBullet GUI):
    - Mouse drag      -> rotate camera
    - Mouse scroll    -> zoom in/out
    - Right-drag      -> pan
    - Step delay slider on the right -> control simulation speed
    - Close window    -> quit
"""
import pybullet as p
import pybullet_data
import numpy as np
import time
import os
from env.swarm_env import SwarmEnv
from agents.maddpg import MADDPG
import config

AGENT_COLORS = [
    [0.0, 0.83, 0.67, 1.0],
    [0.23, 0.51, 0.96, 1.0],
    [0.65, 0.55, 0.98, 1.0],
    [0.96, 0.62, 0.04, 1.0],
]
GOAL_COLORS = [
    [0.0,  0.71, 0.55, 0.65],
    [0.16, 0.39, 0.78, 0.65],
    [0.51, 0.39, 0.78, 0.65],
    [0.78, 0.47, 0.0,  0.65],
]
OBS_COLOR  = [0.94, 0.27, 0.27, 1.0]
WALL_COLOR = [0.30, 0.35, 0.45, 1.0]

SCALE = 2.5  # env coords are +/- 1, world coords are +/- 2.5

def main():
    p.connect(p.GUI)
    p.setGravity(0, 0, 0)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
    p.configureDebugVisualizer(p.COV_ENABLE_SHADOWS, 1)
    p.configureDebugVisualizer(p.COV_ENABLE_RGB_BUFFER_PREVIEW, 0)
    p.configureDebugVisualizer(p.COV_ENABLE_DEPTH_BUFFER_PREVIEW, 0)
    p.configureDebugVisualizer(p.COV_ENABLE_SEGMENTATION_MARK_PREVIEW, 0)

    p.resetDebugVisualizerCamera(
        cameraDistance=5.8,
        cameraYaw=45,
        cameraPitch=-42,
        cameraTargetPosition=[0, 0, 0]
    )

    p.loadURDF("plane.urdf")

    # Arena walls
    arena = SCALE
    wall_h = 0.2
    wall_t = 0.05
    for (px, py, sx, sy) in [
        ( arena,  0,     wall_t, arena),
        (-arena,  0,     wall_t, arena),
        ( 0,      arena, arena,  wall_t),
        ( 0,     -arena, arena,  wall_t),
    ]:
        col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[sx, sy, wall_h])
        vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[sx, sy, wall_h], rgbaColor=WALL_COLOR)
        p.createMultiBody(0, col, vis, [px, py, wall_h])

    # Env + policy
    env    = SwarmEnv(n_agents=config.N_AGENTS, n_obstacles=config.N_DYN_OBSTACLES)
    maddpg = MADDPG(config.N_AGENTS, env.obs_dim, env.action_dim)

    model_path = 'checkpoints/best_model.pt'
    if os.path.exists(model_path):
        maddpg.load(model_path)
        print('Loaded trained model from', model_path)
    else:
        print('No trained model found, using untrained policy')

    # Agent bodies (cylinder + white sphere cap so direction is visible)
    agent_bodies = []
    agent_caps   = []
    for i in range(config.N_AGENTS):
        col = p.createCollisionShape(p.GEOM_CYLINDER, radius=0.15, height=0.30)
        vis = p.createVisualShape(p.GEOM_CYLINDER, radius=0.15, length=0.30, rgbaColor=AGENT_COLORS[i])
        body = p.createMultiBody(0, col, vis, [0, 0, 0.15])
        agent_bodies.append(body)
        cap_vis = p.createVisualShape(p.GEOM_SPHERE, radius=0.08, rgbaColor=[1, 1, 1, 1])
        cap = p.createMultiBody(0, -1, cap_vis, [0, 0, 0.34])
        agent_caps.append(cap)

    # Goal disks (translucent cylinders flat on the floor)
    goal_bodies = []
    for i in range(config.N_AGENTS):
        vis = p.createVisualShape(p.GEOM_CYLINDER, radius=0.20, length=0.02, rgbaColor=GOAL_COLORS[i])
        body = p.createMultiBody(0, -1, vis, [0, 0, 0.011])
        goal_bodies.append(body)

    # Dynamic obstacles (red spheres)
    obstacle_bodies = []
    for i in range(config.N_DYN_OBSTACLES):
        col = p.createCollisionShape(p.GEOM_SPHERE, radius=0.20)
        vis = p.createVisualShape(p.GEOM_SPHERE, radius=0.20, rgbaColor=OBS_COLOR)
        body = p.createMultiBody(0, col, vis, [0, 0, 0.20])
        obstacle_bodies.append(body)

    speed_slider = p.addUserDebugParameter("Step delay (sec)", 0.0, 0.5, 0.12)

    obs_all     = env.reset()
    episode     = 1
    steps       = 0
    total_goals = 0
    collisions  = 0
    hud_id      = -1

    while p.isConnected():
        actions = maddpg.select_actions(obs_all, noise=0.0)
        obs_all, rewards, dones, _ = env.step(actions)
        steps       += 1
        total_goals += sum(dones)

        # Collision counting
        for i in range(len(env.agents)):
            for j in range(i+1, len(env.agents)):
                if np.linalg.norm(env.agents[i].pos - env.agents[j].pos) < 0.12:
                    collisions += 1
            for o in env.obstacles:
                if np.linalg.norm(env.agents[i].pos - o.pos) < 0.13:
                    collisions += 1

        # Update agent visuals
        for i, agent in enumerate(env.agents):
            x = float(agent.pos[0]) * SCALE
            y = float(agent.pos[1]) * SCALE
            vel = agent.vel
            yaw = float(np.arctan2(vel[1], vel[0])) if np.linalg.norm(vel) > 1e-3 else 0.0
            quat = p.getQuaternionFromEuler([0, 0, yaw])
            p.resetBasePositionAndOrientation(agent_bodies[i], [x, y, 0.15], quat)
            p.resetBasePositionAndOrientation(agent_caps[i],   [x, y, 0.34], [0, 0, 0, 1])

        for i, goal in enumerate(env.goals):
            x = float(goal[0]) * SCALE
            y = float(goal[1]) * SCALE
            p.resetBasePositionAndOrientation(goal_bodies[i], [x, y, 0.011], [0, 0, 0, 1])

        for i, o in enumerate(env.obstacles):
            x = float(o.pos[0]) * SCALE
            y = float(o.pos[1]) * SCALE
            p.resetBasePositionAndOrientation(obstacle_bodies[i], [x, y, 0.20], [0, 0, 0, 1])

        # HUD
        hud = ('Episode ' + str(episode) +
               '   Step ' + str(steps) + '/' + str(config.MAX_STEPS) +
               '   Goals ' + str(total_goals) +
               '   Collisions ' + str(collisions))
        if hud_id == -1:
            hud_id = p.addUserDebugText(hud, [0, 0, 1.6], [1, 1, 1], textSize=1.4)
        else:
            hud_id = p.addUserDebugText(hud, [0, 0, 1.6], [1, 1, 1], textSize=1.4,
                                        replaceItemUniqueId=hud_id)

        if steps >= config.MAX_STEPS or all(dones):
            obs_all = env.reset()
            steps   = 0
            episode += 1

        delay = p.readUserDebugParameter(speed_slider)
        time.sleep(delay)

    p.disconnect()


if __name__ == '__main__':
    main()

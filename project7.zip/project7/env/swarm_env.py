import numpy as np

class DynamicObstacle:
    def __init__(self, pos, speed=0.03, pattern='random'):
        self.pos     = np.array(pos, dtype=np.float32)
        self.speed   = speed
        self.pattern = pattern
        self.radius  = 0.08
        self.angle   = np.random.uniform(0, 2*np.pi)
        self.vel     = np.array([np.cos(self.angle), np.sin(self.angle)], dtype=np.float32) * speed

    def step(self):
        if self.pattern == 'circular':
            self.angle += 0.05
            self.vel = np.array([np.cos(self.angle), np.sin(self.angle)], dtype=np.float32) * self.speed
        elif self.pattern == 'random':
            self.vel += np.random.randn(2).astype(np.float32) * 0.005
            norm = np.linalg.norm(self.vel)
            if norm > self.speed:
                self.vel = self.vel / norm * self.speed
        self.pos += self.vel
        self.pos = np.clip(self.pos, -1.0, 1.0)
        if abs(self.pos[0]) >= 1.0: self.vel[0] *= -1
        if abs(self.pos[1]) >= 1.0: self.vel[1] *= -1


class Agent:
    def __init__(self, pos):
        self.pos       = np.array(pos, dtype=np.float32)
        self.vel       = np.zeros(2, dtype=np.float32)
        self.radius    = 0.06
        self.max_speed = 0.07


class SwarmEnv:
    def __init__(self, n_agents=4, n_obstacles=3):
        self.n_agents    = n_agents
        self.n_obstacles = n_obstacles
        self.obs_dim     = 2 + 2 + 2 + (n_agents-1)*2 + n_obstacles*4
        self.action_dim  = 2
        self.agents      = []
        self.goals       = []
        self.obstacles   = []
        self.prev_dists  = []
        self.patterns    = ['circular', 'random', 'circular', 'random', 'circular']

    def reset(self):
        self.agents = []
        self.goals  = []
        positions   = set()

        for i in range(self.n_agents):
            while True:
                pos = np.random.uniform(-0.8, 0.8, 2).astype(np.float32)
                if all(np.linalg.norm(pos - np.array(p)) > 0.2 for p in positions):
                    break
            positions.add(tuple(pos))
            self.agents.append(Agent(pos))

        for i in range(self.n_agents):
            while True:
                goal = np.random.uniform(-0.8, 0.8, 2).astype(np.float32)
                if all(np.linalg.norm(goal - np.array(p)) > 0.2 for p in positions):
                    break
            positions.add(tuple(goal))
            self.goals.append(goal)

        patterns = self.patterns * 10
        self.obstacles = [
            DynamicObstacle(
                pos=np.random.uniform(-0.7, 0.7, 2).astype(np.float32),
                pattern=patterns[i]
            ) for i in range(self.n_obstacles)
        ]

        self.prev_dists = [
            float(np.linalg.norm(self.agents[i].pos - self.goals[i]))
            for i in range(self.n_agents)
        ]
        return self._get_all_obs()

    def _get_obs(self, i):
        agent    = self.agents[i]
        goal     = self.goals[i]
        rel_goal = goal - agent.pos
        others   = []
        for j, other in enumerate(self.agents):
            if j != i:
                others.extend(other.pos - agent.pos)
        dyn = []
        for obs in self.obstacles:
            dyn.extend([*(obs.pos - agent.pos), *obs.vel])
        return np.concatenate([agent.pos, agent.vel, rel_goal,
                                np.array(others, dtype=np.float32),
                                np.array(dyn, dtype=np.float32)])

    def _get_all_obs(self):
        return [self._get_obs(i) for i in range(self.n_agents)]

    def step(self, actions):
        for i, agent in enumerate(self.agents):
            action    = np.clip(actions[i], -1, 1) * agent.max_speed
            agent.vel = action.astype(np.float32)
            agent.pos = np.clip(agent.pos + agent.vel, -1.0, 1.0)

        for obs in self.obstacles:
            obs.step()

        rewards = []
        dones   = []
        for i, agent in enumerate(self.agents):
            r = 0.0
            dist_goal = float(np.linalg.norm(agent.pos - self.goals[i]))

            # progress reward: strong dense signal for moving toward goal
            progress = self.prev_dists[i] - dist_goal
            r += 10.0 * progress
            self.prev_dists[i] = dist_goal

            # mild distance shaping (still pulls toward goal)
            r -= 0.3 * dist_goal

            # big bonus for actually reaching the goal
            if dist_goal < 0.05:
                r += 10.0

            # agent-agent collision: softer hard penalty, gentle danger zone
            for j, other in enumerate(self.agents):
                if j != i:
                    d = float(np.linalg.norm(agent.pos - other.pos))
                    if d < 0.12:
                        r -= 2.0
                    elif d < 0.22:
                        r -= 1.0 * (0.22 - d)

            # dynamic obstacle: a bit stronger because they move unpredictably
            for obs in self.obstacles:
                d = float(np.linalg.norm(agent.pos - obs.pos))
                if d < 0.13:
                    r -= 3.0
                elif d < 0.27:
                    r -= 1.5 * (0.27 - d)

            rewards.append(r)
            dones.append(dist_goal < 0.05)

        return self._get_all_obs(), rewards, dones, {}
